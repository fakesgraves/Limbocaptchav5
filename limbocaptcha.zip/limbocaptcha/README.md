# LimboCaptcha

Velocity-плагин (Velocity API 3.4.0), который перед авторизацией через
**LimboAuth** отправляет игрока в отдельный **captcha-лимбо** (через
**LimboAPI**), показывает в чате ссылку и **сам раздаёт страницу с Google
reCAPTCHA v2** через встроенный веб-сервер — никакого стороннего сайта,
хостинга, PHP или базы данных не требуется.

## ⚠️ Важное предупреждение

Этот код написан без доступа к интернету/Maven-репозиториям в среде, где он
собирался, поэтому я не смог реально скомпилировать проект против настоящих
jar-файлов LimboAPI и гарантировать 0 ошибок компиляции. Код построен на
основе официального публичного API LimboAPI:

- `net.elytrium.limboapi.api.event.LoginLimboRegisterEvent` — событие входа в
  login-лимбо (`getPlayer()`, `addOnJoinCallback(Runnable)`).
- `net.elytrium.limboapi.api.LimboFactory` — `createVirtualWorld(...)`,
  `createLimbo(VirtualWorld)`, `passLoginLimbo(Player)` (передаёт игрока
  следующему зарегистрированному login-лимбо — это и есть эстафета LimboAuth).
- `net.elytrium.limboapi.api.LimboSessionHandler` / `Limbo` / `LimboPlayer`.

**Что сделать после распаковки архива:**

1. Открыть проект в IntelliJ IDEA / VS Code с Maven.
2. Выполнить `mvn clean package`. Maven подтянет реальные `velocity-api` и
   `limboapi:api` из репозиториев, указанных в `pom.xml`.
3. Если компилятор укажет на несовпадение имени метода — IDE подскажет
   правильное через автодополнение (Ctrl+Space) прямо в реальном jar-файле
   LimboAPI. Такие правки обычно занимают 1-2 минуты.
4. Проверьте актуальный номер версии `velocity-api` (3.4.0) — поправьте
   `<velocity.version>` в `pom.xml`, если нужно.

## Как это работает

1. Игрок подключается к прокси.
2. Если игрок **уже проходил капчу недавно** (по умолчанию — за последние
   24 часа, настраивается через `remember.hours`) — капча вообще не
   показывается, игрок сразу передаётся на авторизацию LimboAuth.
3. Иначе: LimboAPI вызывает `LoginLimboRegisterEvent`. Наш листенер подписан
   с `@Subscribe(order = PostOrder.FIRST)`, поэтому наш `addOnJoinCallback`
   срабатывает раньше, чем это делает LimboAuth. Игрока спавнит в
   captcha-лимбо, в чат приходит ссылка вида
   `https://ваш-домен/captcha?token=XXXXXXXX`.
4. Игрок открывает ссылку — **страницу отдаёт сам плагин** из файла
   `plugins/limbocaptcha/web/captcha.html`.
5. Игрок проходит капчу и жмёт кнопку — обычная HTML-форма отправляется на
   `/api/verify` того же встроенного сервера (работает даже без JS у игрока).
6. Плагин сам проверяет ответ через Google `siteverify` (secret-key никогда
   не покидает прокси) и делает редирект на `success.html` или `failed.html`
   из той же папки `web/`.
7. При успехе — `LimboFactory#passLoginLimbo(player)` передаёт игрока на
   авторизацию LimboAuth, а также запоминает UUID игрока на `remember.hours`
   часов, чтобы не мучить повторной капчей при следующих заходах.
8. При провале или истечении `token-ttl-seconds` — кик с сообщением из
   `config.yml`.

## Настройка

### 1. config.yml

Создаётся автоматически в `plugins/limbocaptcha/config.yml` при первом
запуске. Здесь только технические параметры — домен, порт, ключи reCAPTCHA,
время запоминания, координаты лимбо, сообщения в чате Minecraft:

```yaml
web:
  domain: "example.com"
  path: "/captcha"
  verify-path: "/api/verify"
  use-https: true
  bind-address: "0.0.0.0"
  port: 8765

recaptcha:
  site-key: "..."
  secret-key: "..."

remember:
  enabled: true
  hours: 24

limbo:
  world:
    dimension: "OVERWORLD"
    y: 1000.0

token-ttl-seconds: 300
reminder-interval-seconds: 20

messages:
  captcha-prompt: "..."
  captcha-reminder: "..."
  captcha-success: "..."
  captcha-remembered: "..."
  kick-failed: "..."
  kick-timeout: "..."
```

### 2. Страницы капчи — папка web/

Внешний вид того, что видит игрок в браузере, находится **не в конфиге**, а
в обычных HTML-файлах:

```
plugins/limbocaptcha/web/
├── captcha.html   — форма с виджетом reCAPTCHA (первая страница)
├── success.html   — страница при успешном прохождении
└── failed.html    — страница при провале / просроченной / неверной ссылке
```

Эти три файла копируются автоматически при первом запуске (дефолтные версии
лежат внутри jar), дальше плагин **читает их прямо с диска при каждом
запросе** — правите файл, обновляете страницу в браузере, изменения видны
сразу, без перезапуска прокси.

Редактируйте их как обычные статические HTML-страницы: меняйте тексты, CSS,
добавляйте свой JS, логотипы, что угодно. Единственное требование —
сохранить в `captcha.html` форму, отправляющую `POST` на `{{VERIFY_URL}}` с
полями `token` и `g-recaptcha-response`, и три плейсхолдера, которые плагин
подставляет перед отдачей:

| Файл | Плейсхолдер | Что подставляется |
|---|---|---|
| `captcha.html` | `{{SITE_KEY}}` | `recaptcha.site-key` из config.yml |
| `captcha.html` | `{{TOKEN}}` | одноразовый токен текущей сессии игрока |
| `captcha.html` | `{{VERIFY_URL}}` | путь встроенного API проверки |
| `failed.html` | `{{REASON}}` | причина провала (необязательно, можно убрать) |

`success.html` плейсхолдеров не требует — это полностью статическая страница.

## Домен и HTTPS

Плагин раздаёт страницы сам, но по чистому `http://` браузеры могут
блокировать часть функциональности, и это менее безопасно. Рекомендуемая
схема — nginx перед плагином:

```nginx
server {
    listen 443 ssl;
    server_name captcha.example.com;

    ssl_certificate     /etc/letsencrypt/live/captcha.example.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/captcha.example.com/privkey.pem;

    location / {
        proxy_pass http://127.0.0.1:8765;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }
}
```

В `config.yml`: `web.bind-address: "127.0.0.1"` (порт недоступен извне
напрямую), `web.domain: "captcha.example.com"`, `web.use-https: true`.

Без домена/SSL — можно `use-https: false` и открыть `web.port` в файрволе
напрямую: `http://ваш-ip:8765/captcha?token=...`. Рабочий вариант для тестов.

## "Запоминание" прохождения капчи (без БД)

Вместо базы данных используется один файл
`plugins/limbocaptcha/verified-players.dat` (простой формат `UUID=время`, по
записи на игрока). При успешном прохождении капчи UUID игрока и текущее
время сохраняются туда; при следующем заходе, если прошло меньше
`remember.hours` часов — капча не показывается вовсе.

Файл периодически (раз в 5 минут) сохраняется на диск и чистится от старых
записей, а также сохраняется при штатной остановке прокси. Чтобы сбросить
"память" для всех игроков — просто удалите файл при выключенном прокси.

## Структура проекта

```
limbocaptcha/
├── pom.xml
├── .github/workflows/build.yml         — CI: распаковка сурсов + сборка Maven
├── src/main/java/limbocaptcha/
│   ├── LimboCaptchaPlugin.java         — точка входа плагина
│   ├── config/
│   │   ├── PluginConfig.java           — модель config.yml
│   │   └── ConfigManager.java          — загрузка config.yml
│   ├── listener/
│   │   └── LimboRegisterListener.java  — хук на LoginLimboRegisterEvent + remember-проверка
│   ├── limbo/
│   │   └── CaptchaLimboHandler.java    — обработчик игрока в captcha-лимбо
│   ├── session/
│   │   ├── CaptchaSession.java
│   │   └── CaptchaSessionManager.java  — хранилище активных токенов (в памяти)
│   ├── memory/
│   │   └── VerificationMemory.java     — "запоминание" на 24ч (файл вместо БД)
│   ├── http/
│   │   ├── CaptchaHttpServer.java      — встроенный веб-сервер (страницы + API)
│   │   └── WebTemplateManager.java     — копирование/рендер файлов из web/
│   ├── recaptcha/
│   │   └── RecaptchaVerifier.java      — проверка через Google siteverify
│   └── util/
│       └── MessageUtil.java            — рендер чат-сообщений (MiniMessage)
└── src/main/resources/
    ├── config.yml                      — дефолтный конфиг
    └── web/
        ├── captcha.html                — дефолтная страница с формой капчи
        ├── success.html                — дефолтная страница успеха
        └── failed.html                 — дефолтная страница провала
```

## Сборка через GitHub Actions

`.github/workflows/build.yml`:

- запускается при push/PR в `main`/`master`, при тегах `v*`, и вручную;
- **сначала распаковывает** любой `*.zip`-архив, найденный в корне
  репозитория (например, если вы просто закинули скачанный
  `limbocaptcha.zip` в репозиторий, не распаковывая его локально) — архив
  может быть с одной корневой папкой внутри (`limbocaptcha/pom.xml`) или без
  неё (`pom.xml` сразу в корне архива), скрипт понимает оба варианта;
- если zip не найден — просто использует то, что уже есть в репозитории;
- проверяет, что `pom.xml` в итоге на месте, иначе падает с понятной ошибкой;
- ставит JDK 17 (Temurin) с кешем Maven, собирает `mvn -B clean package`;
- находит итоговый jar (не `original-*.jar` от shade-плагина) и кладёт в
  **Artifacts**;
- на теге `v1.0.0` и т.п. — дополнительно создаёт GitHub Release с jar.

Чтобы получить готовый jar: закиньте архив `limbocaptcha.zip` (как есть,
можно не распаковывать) в корень нового репозитория и запушьте, либо просто
скопируйте содержимое архива напрямую — оба варианта сработают. Дождитесь
зелёной галочки во вкладке Actions и скачайте jar из Artifacts.

**Про странные расширения при скачивании (например, `.jar.cac`):** если файл
после скачивания через Artifacts вдруг не открывается / имеет непонятное
расширение — это почти всегда антивирус на вашем ПК, который карантинит
`.jar`-файлы. Проверьте карантин/журнал защиты антивируса и восстановите
файл оттуда, либо переименуйте расширение обратно в `.jar` и откройте архив
через 7-Zip/WinRAR, чтобы убедиться, что содержимое цело.

## Зависимости на проксе

- **LimboAPI** — обязательна, без неё плагин не запустится.
- **LimboAuth** — не обязательна как maven-зависимость (плагин её не
  импортирует напрямую), но по смыслу должна стоять на проксе и тоже
  использовать `LoginLimboRegisterEvent`, чтобы `passLoginLimbo` передавал
  игрока именно ей.
