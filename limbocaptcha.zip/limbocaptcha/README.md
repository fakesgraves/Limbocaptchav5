# LimboCaptcha

Velocity-плагин (Velocity API 3.4.0), который перед авторизацией через
**LimboAuth** отправляет игрока в отдельный **captcha-лимбо** (через
**LimboAPI**), показывает в чате ссылку и **сам раздаёт страницу с Google
reCAPTCHA v2** через встроенный веб-сервер — никакого стороннего сайта,
хостинга или PHP не требуется. Всё, что видит игрок на странице (тексты,
цвета, логотип), настраивается через `config.yml` плагина.

## ⚠️ Важное предупреждение

Этот код написан без доступа к интернету/Maven-репозиториям в среде, где он
собирался, поэтому я не смог реально скомпилировать проект против настоящих
jar-файлов LimboAPI и гарантировать 0 ошибок компиляции. Код построен на
основе официального публичного API LimboAPI:

- `net.elytrium.limboapi.api.event.LoginLimboRegisterEvent` — событие входа в
  login-лимбо (`getPlayer()`, `addOnJoinCallback(Runnable)`).
- `net.elytrium.limboapi.api.LimboFactory` — `createVirtualWorld(...)`,
  `createLimbo(VirtualWorld)`, `passLoginLimbo(Player)` (передаёт игрока
  следующему зарегистрированному login-лимбо — это и есть эстафета LimboAuth).
- `net.elytrium.limboapi.api.LimboSessionHandler` / `Limbo` / `LimboPlayer`.

Слой БД (HikariCP + SQLite/MySQL JDBC-драйверы) написан на чистом JDBC без
ORM — эти API очень стабильны, риск несовпадения версий там минимальный.

**Что сделать после распаковки архива:**

1. Открыть проект в IntelliJ IDEA / VS Code с Maven.
2. Выполнить `mvn clean package`. Maven подтянет реальные `velocity-api` и
   `limboapi:api` из репозиториев, указанных в `pom.xml`.
3. Если компилятор укажет на несовпадение имени метода — IDE подскажет
   правильное через автодополнение (Ctrl+Space) прямо в реальном jar-файле
   LimboAPI. Такие правки обычно занимают 1-2 минуты.
4. Проверьте актуальный номер версии `velocity-api` (3.4.0) в
   https://repo.papermc.io/repository/maven-public/com/velocitypowered/velocity-api/ —
   поправьте `<velocity.version>` в `pom.xml`, если нужно.

## Как это работает

1. Игрок подключается к прокси.
2. LimboAPI вызывает `LoginLimboRegisterEvent`. Наш листенер подписан с
   `@Subscribe(order = PostOrder.FIRST)`, поэтому наш `addOnJoinCallback`
   срабатывает раньше, чем это делает LimboAuth.
3. Игрока спавнит в captcha-лимбо (виртуальный пустой мир), в чат приходит
   сообщение с прямой ссылкой:
   `https://ваш-домен/captcha?token=XXXXXXXX`.
4. Игрок открывает ссылку — **эту страницу отдаёт сам плагин**, она уже
   содержит виджет Google reCAPTCHA v2 и все тексты/цвета из вашего
   `config.yml` (класс `CaptchaPageRenderer`).
5. Игрок проходит капчу и жмёт кнопку. Страница отправляет ответ на
   `/api/verify` того же встроенного сервера.
6. Плагин сам проверяет ответ через Google `siteverify` (сервер-сервер,
   secret-key никогда не покидает прокси).
7. При успехе — `LimboFactory#passLoginLimbo(player)`, что передаёт игрока
   следующему login-лимбо, то есть на авторизацию LimboAuth. Ничего вручную
   делать не нужно.
8. При провале или истечении `token-ttl-seconds` — кик с сообщением из
   конфига.

## Настройка — всё в одном config.yml

Файл создастся автоматически в `plugins/limbocaptcha/config.yml` при первом
запуске. Никакого HTML/CSS/JS редактировать не нужно — всё, что видит игрок,
собирается плагином на лету из этого файла:

```yaml
web:
  domain: "example.com"       # домен/IP, по которому откроется страница
  path: "/captcha"
  verify-path: "/api/verify"
  use-https: true             # true только если реально настроен SSL
  bind-address: "0.0.0.0"
  port: 8765
  cors-origin: "*"

recaptcha:
  site-key: "..."             # с https://www.google.com/recaptcha/admin
  secret-key: "..."

page:
  title: "Проверка безопасности"
  subtitle: "Подтвердите, что вы не робот, чтобы подключиться к серверу"
  server-name: "MyServer"
  site-url: "https://example.com"
  logo-url: ""
  accent-color: "#6366f1"
  success-color: "#10b981"
  error-color: "#ef4444"
  button-text: "Подтвердить и продолжить"
  success-title: "Проверка пройдена"
  success-text: "..."
  failed-title: "Подключение заблокировано"
  failed-text: "..."
  invalid-link-text: "..."

database:
  type: "sqlite"               # или "mysql" для внешней базы

limbo:
  world:
    dimension: "OVERWORLD"
    y: 1000.0

token-ttl-seconds: 300
reminder-interval-seconds: 20

messages:
  captcha-prompt: "..."        # MiniMessage-теги: <green>, <click:open_url:'...'> и т.д.
  captcha-reminder: "..."
  captcha-success: "..."
  kick-failed: "..."
  kick-timeout: "..."
```

Поменяли `config.yml` → перезапустили прокси → страница и сообщения
обновились. Код трогать не нужно.

## Домен и HTTPS

Плагин раздаёт страницу сам, но по чистому `http://` современные браузеры
могут блокировать некоторые вещи (и `http` менее безопасен). Рекомендуемая
схема:

1. Ставите nginx перед плагином, получаете SSL-сертификат (Let's Encrypt).
2. `web.bind-address: "127.0.0.1"` в конфиге — порт плагина недоступен извне
   напрямую.
3. Конфиг nginx:
   ```nginx
   server {
       listen 443 ssl;
       server_name captcha.example.com;

       ssl_certificate     /etc/letsencrypt/live/captcha.example.com/fullchain.pem;
       ssl_certificate_key /etc/letsencrypt/live/captcha.example.com/privkey.pem;

       location / {
           proxy_pass http://127.0.0.1:8765;
           proxy_set_header Host $host;
           proxy_set_header X-Real-IP $remote_addr;
       }
   }
   ```
4. В `config.yml`: `web.domain: "captcha.example.com"`, `web.use-https: true`,
   `web.port: 8765` (плагин слушает этот порт локально — nginx обращается к
   нему, а игроки видят только 443 без порта в ссылке, т.к. `buildCaptchaLink`
   не добавляет порт для стандартных 443/80).

Если у вас нет домена/SSL — можно оставить `use-https: false` и открыть порт
`web.port` в файрволе напрямую, ссылка будет вида
`http://ваш-ip:8765/captcha?token=...`. Рабочий, но менее безопасный вариант
для тестов.

## Структура проекта

```
limbocaptcha/
├── pom.xml
├── .github/workflows/build.yml         — CI: распаковка сурсов + сборка Maven
├── src/main/java/limbocaptcha/
│   ├── LimboCaptchaPlugin.java         — точка входа плагина
│   ├── config/
│   │   ├── PluginConfig.java           — модель конфига (включая внешний вид страницы)
│   │   └── ConfigManager.java          — загрузка config.yml
│   ├── listener/
│   │   └── LimboRegisterListener.java  — хук на LoginLimboRegisterEvent
│   ├── limbo/
│   │   └── CaptchaLimboHandler.java    — обработчик игрока в captcha-лимбо
│   ├── session/
│   │   ├── CaptchaSession.java
│   │   └── CaptchaSessionManager.java  — хранилище активных токенов
│   ├── database/
│   │   ├── DatabaseManager.java        — подключение к БД (HikariCP), схема
│   │   ├── CaptchaRecordDao.java       — история проверок captcha_sessions
│   │   └── CaptchaRecord.java          — модель одной записи
│   ├── http/
│   │   ├── CaptchaHttpServer.java      — встроенный веб-сервер (страница + API)
│   │   └── CaptchaPageRenderer.java    — сборка HTML страницы из config.yml
│   ├── recaptcha/
│   │   └── RecaptchaVerifier.java      — проверка через Google siteverify
│   └── util/
│       └── MessageUtil.java            — рендер чат-сообщений (MiniMessage)
└── src/main/resources/config.yml       — дефолтный конфиг
```

## Сборка через GitHub Actions

`.github/workflows/build.yml`:

- запускается при push/PR в `main`/`master`, при тегах `v*`, и вручную;
- **сначала распаковывает** любой `*.zip`-архив, найденный в корне
  репозитория (например, если вы просто закинули скачанный
  `limbocaptcha.zip` в репозиторий, не распаковывая его локально) — архив
  может быть с одной корневой папкой внутри (`limbocaptcha/pom.xml`) или без
  неё (`pom.xml` сразу в корне архива), скрипт понимает оба варианта;
- если zip не найден — просто использует то, что уже есть в репозитории
  (например, если вы закоммитили файлы напрямую, без архива);
- проверяет, что `pom.xml` в итоге на месте, иначе явно падает с понятной
  ошибкой;
- ставит JDK 17 (Temurin) с кешем Maven, собирает `mvn -B clean package`;
- находит итоговый jar (не `original-*.jar` от shade-плагина) и кладёт в
  **Artifacts**;
- на теге `v1.0.0` и т.п. — дополнительно создаёт GitHub Release с jar.

Чтобы получить готовый jar: закиньте архив `limbocaptcha.zip` (как есть,
можно не распаковывать) в корень нового репозитория и запушьте, либо просто
скопируйте содержимое архива напрямую — оба варианта сработают. Дождитесь
зелёной галочки во вкладке Actions и скачайте jar из Artifacts. Для
автоматического релиза: `git tag v1.0.0 && git push origin v1.0.0`.

## Зависимости на проксе

- **LimboAPI** — обязательна, без неё плагин не запустится.
- **LimboAuth** — не обязательна как maven-зависимость (плагин её не
  импортирует напрямую), но по смыслу должна стоять на проксе и тоже
  использовать `LoginLimboRegisterEvent`, чтобы `passLoginLimbo` передавал
  игрока именно ей.
