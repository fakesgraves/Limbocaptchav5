package limbocaptcha.config;

import org.yaml.snakeyaml.Yaml;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.logging.Logger;

/**
 * Копирует config.yml по умолчанию в папку данных плагина (если его там ещё нет)
 * и разбирает YAML вручную в {@link PluginConfig}, т.к. в файле используется
 * kebab-case (site-key и т.д.), а не имена java-полей.
 */
public final class ConfigManager {

    private final Path dataDirectory;
    private final Logger logger;

    public ConfigManager(Path dataDirectory, Logger logger) {
        this.dataDirectory = dataDirectory;
        this.logger = logger;
    }

    public PluginConfig load() {
        try {
            Files.createDirectories(this.dataDirectory);
            Path configFile = this.dataDirectory.resolve("config.yml");

            if (!Files.exists(configFile)) {
                try (InputStream in = getClass().getClassLoader().getResourceAsStream("config.yml")) {
                    if (in == null) {
                        throw new IllegalStateException("Не найден config.yml внутри jar (src/main/resources)");
                    }
                    Files.copy(in, configFile);
                    this.logger.info("Создан дефолтный config.yml: " + configFile);
                }
            }

            try (InputStream in = Files.newInputStream(configFile)) {
                Yaml yaml = new Yaml();
                Map<String, Object> root = yaml.load(in);
                return map(root == null ? new LinkedHashMap<>() : root);
            }
        } catch (IOException e) {
            throw new RuntimeException("Не удалось загрузить config.yml", e);
        }
    }

    @SuppressWarnings("unchecked")
    private PluginConfig map(Map<String, Object> root) {
        PluginConfig cfg = new PluginConfig();

        Map<String, Object> web = subMap(root, "web");
        cfg.web.domain = str(web, "domain", cfg.web.domain);
        cfg.web.path = str(web, "path", cfg.web.path);
        cfg.web.verifyPath = str(web, "verify-path", cfg.web.verifyPath);
        cfg.web.useHttps = bool(web, "use-https", cfg.web.useHttps);
        cfg.web.bindAddress = str(web, "bind-address", cfg.web.bindAddress);
        cfg.web.port = intVal(web, "port", cfg.web.port);

        Map<String, Object> recaptcha = subMap(root, "recaptcha");
        cfg.recaptcha.siteKey = str(recaptcha, "site-key", cfg.recaptcha.siteKey);
        cfg.recaptcha.secretKey = str(recaptcha, "secret-key", cfg.recaptcha.secretKey);
        cfg.recaptcha.verifyUrl = str(recaptcha, "verify-url", cfg.recaptcha.verifyUrl);

        Map<String, Object> remember = subMap(root, "remember");
        cfg.remember.enabled = bool(remember, "enabled", cfg.remember.enabled);
        cfg.remember.hours = longVal(remember, "hours", cfg.remember.hours);

        Map<String, Object> limbo = subMap(root, "limbo");
        Map<String, Object> world = subMap(limbo, "world");
        cfg.limbo.world.dimension = str(world, "dimension", cfg.limbo.world.dimension);
        cfg.limbo.world.x = doubleVal(world, "x", cfg.limbo.world.x);
        cfg.limbo.world.y = doubleVal(world, "y", cfg.limbo.world.y);
        cfg.limbo.world.z = doubleVal(world, "z", cfg.limbo.world.z);
        cfg.limbo.world.yaw = (float) doubleVal(world, "yaw", cfg.limbo.world.yaw);
        cfg.limbo.world.pitch = (float) doubleVal(world, "pitch", cfg.limbo.world.pitch);

        cfg.tokenTtlSeconds = longVal(root, "token-ttl-seconds", cfg.tokenTtlSeconds);
        cfg.reminderIntervalSeconds = longVal(root, "reminder-interval-seconds", cfg.reminderIntervalSeconds);

        Object messagesRaw = root.get("messages");
        if (messagesRaw instanceof Map) {
            ((Map<String, Object>) messagesRaw).forEach((k, v) -> cfg.messages.put(k, String.valueOf(v)));
        }

        return cfg;
    }

    @SuppressWarnings("unchecked")
    private Map<String, Object> subMap(Map<String, Object> root, String key) {
        Object o = root.get(key);
        if (o instanceof Map) {
            return (Map<String, Object>) o;
        }
        return new LinkedHashMap<>();
    }

    private String str(Map<String, Object> map, String key, String def) {
        Object o = map.get(key);
        return o == null ? def : String.valueOf(o);
    }

    private boolean bool(Map<String, Object> map, String key, boolean def) {
        Object o = map.get(key);
        return o == null ? def : Boolean.parseBoolean(String.valueOf(o));
    }

    private int intVal(Map<String, Object> map, String key, int def) {
        Object o = map.get(key);
        return o == null ? def : Integer.parseInt(String.valueOf(o));
    }

    private long longVal(Map<String, Object> map, String key, long def) {
        Object o = map.get(key);
        return o == null ? def : Long.parseLong(String.valueOf(o));
    }

    private double doubleVal(Map<String, Object> map, String key, double def) {
        Object o = map.get(key);
        return o == null ? def : Double.parseDouble(String.valueOf(o));
    }
}
