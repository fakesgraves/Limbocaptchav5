package limbocaptcha.config;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * POJO-структура config.yml. Внешний вид HTML-страниц (капча/успех/провал)
 * в этом классе НЕ описывается - он живёт в файлах plugins/limbocaptcha/web/*.html,
 * которые владелец сервера правит напрямую (см. WebTemplateManager).
 */
public class PluginConfig {

    public WebSection web = new WebSection();
    public RecaptchaSection recaptcha = new RecaptchaSection();
    public RememberSection remember = new RememberSection();
    public LimboSection limbo = new LimboSection();
    public long tokenTtlSeconds = 300;
    public long reminderIntervalSeconds = 20;
    public Map<String, String> messages = new LinkedHashMap<>();

    public static class WebSection {
        public String domain = "example.com";
        public String path = "/captcha";
        public String verifyPath = "/api/verify";
        public boolean useHttps = true;
        public String bindAddress = "0.0.0.0";
        public int port = 8765;
    }

    public static class RecaptchaSection {
        public String siteKey = "";
        public String secretKey = "";
        public String verifyUrl = "https://www.google.com/recaptcha/api/siteverify";
    }

    public static class RememberSection {
        public boolean enabled = true;
        public long hours = 24;
    }

    public static class LimboSection {
        public WorldSection world = new WorldSection();
    }

    public static class WorldSection {
        public String dimension = "OVERWORLD";
        public double x = 0.0;
        public double y = 1000.0;
        public double z = 0.0;
        public float yaw = 0.0f;
        public float pitch = 0.0f;
    }

    public String buildCaptchaLink(String token) {
        String scheme = this.web.useHttps ? "https://" : "http://";
        String path = this.web.path.startsWith("/") ? this.web.path : "/" + this.web.path;
        boolean defaultPort = (this.web.useHttps && this.web.port == 443)
                || (!this.web.useHttps && this.web.port == 80);
        String portPart = defaultPort ? "" : (":" + this.web.port);
        return scheme + this.web.domain + portPart + path + "?token=" + token;
    }

    public String message(String key) {
        return this.messages.getOrDefault(key, "");
    }
}
