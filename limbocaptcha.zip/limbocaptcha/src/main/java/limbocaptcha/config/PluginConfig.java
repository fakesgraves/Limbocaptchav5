package limbocaptcha.config;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * POJO-структура config.yml. Все настройки, включая внешний вид HTML-страницы
 * капчи (секция page), задаются здесь - редактировать HTML/JS/CSS не требуется.
 */
public class PluginConfig {

    public WebSection web = new WebSection();
    public RecaptchaSection recaptcha = new RecaptchaSection();
    public PageSection page = new PageSection();
    public DatabaseSection database = new DatabaseSection();
    public LimboSection limbo = new LimboSection();
    public long tokenTtlSeconds = 300;
    public long reminderIntervalSeconds = 20;
    public Map<String, String> messages = new LinkedHashMap<>();

    public static class WebSection {
        public String domain = "example.com";
        public String path = "/captcha";
        public String verifyPath = "/api/verify";
        public boolean useHttps = true;
        public String bindAddress = "0.0.0.0";
        public int port = 8765;
        public String corsOrigin = "*";
    }

    public static class RecaptchaSection {
        public String siteKey = "";
        public String secretKey = "";
        public String verifyUrl = "https://www.google.com/recaptcha/api/siteverify";
    }

    public static class PageSection {
        public String title = "Проверка безопасности";
        public String subtitle = "Подтвердите, что вы не робот, чтобы подключиться к серверу";
        public String serverName = "Server";
        public String siteUrl = "";
        public String logoUrl = "";
        public String accentColor = "#6366f1";
        public String successColor = "#10b981";
        public String errorColor = "#ef4444";
        public String buttonText = "Подтвердить и продолжить";
        public String successTitle = "Проверка пройдена";
        public String successText = "Капча пройдена, возвращайтесь в игру.";
        public String failedTitle = "Подключение заблокировано";
        public String failedText = "Проверка не пройдена, попробуйте зайти на сервер заново.";
        public String invalidLinkText = "Ссылка недействительна или устарела.";
    }

    public static class DatabaseSection {
        public String type = "sqlite"; // sqlite | mysql
        public SqliteSection sqlite = new SqliteSection();
        public MysqlSection mysql = new MysqlSection();
        public PoolSection pool = new PoolSection();
    }

    public static class SqliteSection {
        public String file = "captcha.db";
    }

    public static class MysqlSection {
        public String host = "127.0.0.1";
        public int port = 3306;
        public String database = "limbocaptcha";
        public String username = "limbocaptcha";
        public String password = "";
        public boolean useSsl = false;
        public String tablePrefix = "lc_";
    }

    public static class PoolSection {
        public int maximumPoolSize = 6;
        public long connectionTimeoutMs = 5000;
    }

    public static class LimboSection {
        public WorldSection world = new WorldSection();
    }

    public static class WorldSection {
        public String dimension = "OVERWORLD";
        public double x = 0.0;
        public double y = 1000.0;
        public double z = 0.0;
        public float yaw = 0.0f;
        public float pitch = 0.0f;
    }

    public String buildCaptchaLink(String token) {
        String scheme = this.web.useHttps ? "https://" : "http://";
        String path = this.web.path.startsWith("/") ? this.web.path : "/" + this.web.path;
        boolean defaultPort = (this.web.useHttps && this.web.port == 443)
                || (!this.web.useHttps && this.web.port == 80);
        String portPart = defaultPort ? "" : (":" + this.web.port);
        return scheme + this.web.domain + portPart + path + "?token=" + token;
    }

    public String message(String key) {
        return this.messages.getOrDefault(key, "");
    }
}
