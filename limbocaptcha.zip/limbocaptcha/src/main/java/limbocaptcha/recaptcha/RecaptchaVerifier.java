package limbocaptcha.recaptcha;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.concurrent.CompletableFuture;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Серверная проверка ответа виджета Google reCAPTCHA v2 через
 * https://www.google.com/recaptcha/api/siteverify. JSON разбирается
 * регулярным выражением, т.к. ответ Google очень простой и предсказуемый -
 * подключать отдельную JSON-библиотеку не требуется.
 */
public final class RecaptchaVerifier {

    private static final Pattern SUCCESS_PATTERN = Pattern.compile("\"success\"\\s*:\\s*(true|false)");

    private final HttpClient httpClient = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(5))
            .build();

    private final String verifyUrl;
    private final String secretKey;
    private final Logger logger;

    public RecaptchaVerifier(String verifyUrl, String secretKey, Logger logger) {
        this.verifyUrl = verifyUrl;
        this.secretKey = secretKey;
        this.logger = logger;
    }

    public CompletableFuture<Boolean> verify(String recaptchaResponse, String remoteIp) {
        if (recaptchaResponse == null || recaptchaResponse.isBlank()) {
            return CompletableFuture.completedFuture(false);
        }

        String body = "secret=" + encode(this.secretKey)
                + "&response=" + encode(recaptchaResponse)
                + (remoteIp != null ? "&remoteip=" + encode(remoteIp) : "");

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(this.verifyUrl))
                .timeout(Duration.ofSeconds(8))
                .header("Content-Type", "application/x-www-form-urlencoded")
                .POST(HttpRequest.BodyPublishers.ofString(body, StandardCharsets.UTF_8))
                .build();

        return this.httpClient.sendAsync(request, HttpResponse.BodyHandlers.ofString())
                .thenApply(response -> {
                    if (response.statusCode() != 200) {
                        this.logger.warning("reCAPTCHA siteverify вернул код " + response.statusCode());
                        return false;
                    }
                    Matcher matcher = SUCCESS_PATTERN.matcher(response.body());
                    return matcher.find() && Boolean.parseBoolean(matcher.group(1));
                })
                .exceptionally(ex -> {
                    this.logger.warning("Ошибка при обращении к reCAPTCHA siteverify: " + ex.getMessage());
                    return false;
                });
    }

    private static String encode(String value) {
        return java.net.URLEncoder.encode(value, StandardCharsets.UTF_8);
    }
}
