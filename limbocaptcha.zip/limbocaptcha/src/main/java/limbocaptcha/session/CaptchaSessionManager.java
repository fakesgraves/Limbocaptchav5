package limbocaptcha.session;

import com.velocitypowered.api.proxy.Player;

import java.security.SecureRandom;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;

/**
 * Хранит все текущие ожидающие проверки captcha-сессии.
 * Потокобезопасен - к нему обращаются и из сетевых потоков Velocity,
 * и из потока встроенного HTTP-сервера.
 */
public final class CaptchaSessionManager {

    private static final SecureRandom RANDOM = new SecureRandom();
    private static final char[] ALPHABET =
            "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789".toCharArray();

    private final Map<String, CaptchaSession> byToken = new ConcurrentHashMap<>();
    private final Map<UUID, CaptchaSession> byPlayer = new ConcurrentHashMap<>();

    public CaptchaSession create(Player player, Runnable onSuccess, Consumer<String> onFail) {
        remove(player.getUniqueId());

        String token = generateToken();
        CaptchaSession session = new CaptchaSession(player, token, onSuccess, onFail);
        this.byToken.put(token, session);
        this.byPlayer.put(player.getUniqueId(), session);
        return session;
    }

    public CaptchaSession getByToken(String token) {
        return this.byToken.get(token);
    }

    public CaptchaSession getByPlayer(UUID uuid) {
        return this.byPlayer.get(uuid);
    }

    public void remove(UUID uuid) {
        CaptchaSession existing = this.byPlayer.remove(uuid);
        if (existing != null) {
            this.byToken.remove(existing.getToken());
        }
    }

    public void removeByToken(String token) {
        CaptchaSession existing = this.byToken.remove(token);
        if (existing != null) {
            this.byPlayer.remove(existing.getPlayerId());
        }
    }

    /**
     * @param onExpiredToken опциональный колбэк (например, пометить запись EXPIRED в БД)
     */
    public void purgeExpired(long ttlSeconds, Consumer<String> onExpiredToken) {
        for (CaptchaSession session : this.byToken.values()) {
            if (!session.isCompleted() && session.isExpired(ttlSeconds)) {
                String token = session.getToken();
                session.fail("kick-timeout");
                removeByToken(token);
                if (onExpiredToken != null) {
                    onExpiredToken.accept(token);
                }
            }
        }
    }

    private String generateToken() {
        StringBuilder sb = new StringBuilder(32);
        for (int i = 0; i < 32; i++) {
            sb.append(ALPHABET[RANDOM.nextInt(ALPHABET.length)]);
        }
        return sb.toString();
    }
}
