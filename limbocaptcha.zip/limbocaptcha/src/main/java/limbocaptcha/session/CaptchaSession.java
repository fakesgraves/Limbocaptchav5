package limbocaptcha.session;

import com.velocitypowered.api.proxy.Player;

import java.util.UUID;
import java.util.function.Consumer;

/**
 * Состояние одного игрока, ожидающего прохождения captcha в лимбо.
 */
public final class CaptchaSession {

    private final UUID playerId;
    private final String token;
    private final long createdAtMillis;
    private volatile boolean completed;
    private final Runnable onSuccess;
    private final Consumer<String> onFail;

    public CaptchaSession(Player player, String token, Runnable onSuccess, Consumer<String> onFail) {
        this.playerId = player.getUniqueId();
        this.token = token;
        this.createdAtMillis = System.currentTimeMillis();
        this.onSuccess = onSuccess;
        this.onFail = onFail;
    }

    public UUID getPlayerId() {
        return this.playerId;
    }

    public String getToken() {
        return this.token;
    }

    public boolean isExpired(long ttlSeconds) {
        return System.currentTimeMillis() - this.createdAtMillis > ttlSeconds * 1000L;
    }

    public boolean isCompleted() {
        return this.completed;
    }

    private void markCompleted() {
        this.completed = true;
    }

    public synchronized void succeed() {
        if (this.completed) {
            return;
        }
        markCompleted();
        this.onSuccess.run();
    }

    public synchronized void fail(String reasonKey) {
        if (this.completed) {
            return;
        }
        markCompleted();
        this.onFail.accept(reasonKey);
    }
}
