package limbocaptcha.http;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;
import limbocaptcha.config.PluginConfig;
import limbocaptcha.memory.VerificationMemory;
import limbocaptcha.recaptcha.RecaptchaVerifier;
import limbocaptcha.session.CaptchaSession;
import limbocaptcha.session.CaptchaSessionManager;

import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Единственный встроенный веб-сервер плагина (штатный com.sun.net.httpserver
 * из JDK, без внешних веб-фреймворков). Делает две вещи:
 * <p>
 * 1. GET {web.path} - отдаёт HTML-страницу captcha.html из папки web/,
 *    подставляя токен/site-key/verify-url. Если ссылка недействительна
 *    (нет токена, сессия не найдена или уже завершена) - сразу отдаёт
 *    failed.html вместо формы.
 * <p>
 * 2. POST {web.verify-path} - принимает обычную HTML-форму (application/x-www-
 *    form-urlencoded) с полями token и g-recaptcha-response, проверяет ответ
 *    через Google siteverify и делает HTTP-редирект (302) на success.html
 *    или failed.html - без JSON и без JS на стороне страницы.
 * <p>
 * Никакого стороннего сайта/хостинга не требуется - и страницы, и API живут
 * в одном месте; тексты/вёрстку страниц владелец сервера правит напрямую
 * в файлах plugins/limbocaptcha/web/*.html (см. {@link WebTemplateManager}).
 */
public final class CaptchaHttpServer {

    private static final Pattern TOKEN_PATTERN = Pattern.compile("token=([^&]+)");
    private static final Pattern RESPONSE_PATTERN = Pattern.compile("g-recaptcha-response=([^&]+)");

    private final PluginConfig config;
    private final CaptchaSessionManager sessionManager;
    private final RecaptchaVerifier verifier;
    private final VerificationMemory verificationMemory;
    private final WebTemplateManager templates;
    private final Logger logger;

    private HttpServer server;

    public CaptchaHttpServer(PluginConfig config, CaptchaSessionManager sessionManager,
                              RecaptchaVerifier verifier, VerificationMemory verificationMemory,
                              WebTemplateManager templates, Logger logger) {
        this.config = config;
        this.sessionManager = sessionManager;
        this.verifier = verifier;
        this.verificationMemory = verificationMemory;
        this.templates = templates;
        this.logger = logger;
    }

    public void start() throws IOException {
        this.server = HttpServer.create(
                new InetSocketAddress(this.config.web.bindAddress, this.config.web.port), 0);
        this.server.setExecutor(Executors.newCachedThreadPool());

        String pagePath = normalizePath(this.config.web.path);
        String verifyPath = normalizePath(this.config.web.verifyPath);
        String successPath = joinPath(pagePath, "success");
        String failedPath = joinPath(pagePath, "failed");

        this.server.createContext(pagePath, this::handlePage);
        this.server.createContext(verifyPath, this::handleVerify);
        this.server.createContext(successPath, ex -> serveTemplate(ex, "success.html", Map.of()));
        this.server.createContext(failedPath, ex -> serveTemplate(ex, "failed.html",
                Map.of("REASON", queryParam(ex.getRequestURI().getQuery(), "reason", "Проверка не пройдена."))));
        this.server.start();

        this.logger.info("LimboCaptcha веб-сервер запущен на "
                + this.config.web.bindAddress + ":" + this.config.web.port
                + " (страница: " + pagePath + ", API: " + verifyPath + ")");
    }

    public void stop() {
        if (this.server != null) {
            this.server.stop(0);
        }
    }

    // ---------------------------------------------------------------------
    // GET: страница капчи
    // ---------------------------------------------------------------------

    private void handlePage(HttpExchange exchange) {
        try {
            if (!"GET".equalsIgnoreCase(exchange.getRequestMethod())) {
                sendPlainText(exchange, 405, "Method Not Allowed");
                return;
            }

            String token = queryParam(exchange.getRequestURI().getQuery(), "token", null);
            CaptchaSession session = token != null ? this.sessionManager.getByToken(token) : null;

            if (token == null || session == null || session.isCompleted()) {
                serveTemplate(exchange, "failed.html",
                        Map.of("REASON", "Ссылка недействительна или устарела."));
                return;
            }

            String verifyUrl = normalizePath(this.config.web.verifyPath);
            Map<String, String> placeholders = new HashMap<>();
            placeholders.put("SITE_KEY", this.config.recaptcha.siteKey);
            placeholders.put("TOKEN", token);
            placeholders.put("VERIFY_URL", verifyUrl);

            serveTemplate(exchange, "captcha.html", placeholders);
        } catch (Exception e) {
            this.logger.warning("Ошибка при отдаче страницы капчи: " + e.getMessage());
            try {
                sendPlainText(exchange, 500, "Internal Server Error");
            } catch (IOException ignored) {
                // соединение уже могло быть разорвано
            }
        }
    }

    // ---------------------------------------------------------------------
    // POST: приём формы капчи (обычный HTML form submit, без JS/JSON)
    // ---------------------------------------------------------------------

    private void handleVerify(HttpExchange exchange) {
        try {
            if (!"POST".equalsIgnoreCase(exchange.getRequestMethod())) {
                sendPlainText(exchange, 405, "Method Not Allowed");
                return;
            }

            String body = new String(exchange.getRequestBody().readAllBytes(), StandardCharsets.UTF_8);
            String token = extract(TOKEN_PATTERN, body);
            String recaptchaResponse = decode(extract(RESPONSE_PATTERN, body));

            String pagePath = normalizePath(this.config.web.path);

            if (token == null || token.isBlank()) {
                redirect(exchange, joinPath(pagePath, "failed") + "?reason=" + encode("Отсутствует токен в запросе."));
                return;
            }

            CaptchaSession session = this.sessionManager.getByToken(token);
            if (session == null || session.isCompleted()) {
                redirect(exchange, joinPath(pagePath, "failed")
                        + "?reason=" + encode("Сессия устарела или уже была использована."));
                return;
            }

            String remoteIp = exchange.getRemoteAddress() != null
                    ? exchange.getRemoteAddress().getAddress().getHostAddress() : null;

            // Обычная HTML-форма ожидает синхронный редирект-ответ, а не JSON,
            // поэтому здесь мы дожидаемся результата проверки Google с таймаутом,
            // а не продолжаем асинхронно (запрос и так выполняется в отдельном
            // потоке пула, так что блокировка тут безопасна для остального плагина).
            boolean success;
            try {
                success = this.verifier.verify(recaptchaResponse, remoteIp).get(8, TimeUnit.SECONDS);
            } catch (InterruptedException | ExecutionException | TimeoutException e) {
                this.logger.warning("Проверка reCAPTCHA не завершилась вовремя: " + e.getMessage());
                success = false;
            }

            if (success) {
                this.verificationMemory.markVerified(session.getPlayerId());
                session.succeed();
                redirect(exchange, joinPath(pagePath, "success"));
            } else {
                session.fail("kick-failed");
                this.sessionManager.removeByToken(token);
                redirect(exchange, joinPath(pagePath, "failed")
                        + "?reason=" + encode("Google не подтвердил прохождение капчи."));
            }
        } catch (Exception e) {
            this.logger.warning("Ошибка обработки запроса капчи: " + e.getMessage());
            try {
                sendPlainText(exchange, 500, "Internal Server Error");
            } catch (IOException ignored) {
                // соединение уже могло быть разорвано
            }
        } finally {
            exchange.close();
        }
    }

    // ---------------------------------------------------------------------
    // Утилиты
    // ---------------------------------------------------------------------

    private void serveTemplate(HttpExchange exchange, String fileName, Map<String, String> placeholders) {
        try {
            String html = this.templates.render(fileName, placeholders);
            sendHtml(exchange, 200, html);
        } catch (IOException e) {
            this.logger.warning("Не удалось прочитать шаблон " + fileName + ": " + e.getMessage());
            try {
                sendPlainText(exchange, 500, "Template read error");
            } catch (IOException ignored) {
                // соединение уже могло быть разорвано
            }
        } finally {
            exchange.close();
        }
    }

    private void redirect(HttpExchange exchange, String location) throws IOException {
        exchange.getResponseHeaders().add("Location", location);
        exchange.sendResponseHeaders(302, -1);
    }

    private void sendHtml(HttpExchange exchange, int status, String html) throws IOException {
        byte[] bytes = html.getBytes(StandardCharsets.UTF_8);
        exchange.getResponseHeaders().add("Content-Type", "text/html; charset=utf-8");
        exchange.sendResponseHeaders(status, bytes.length);
        try (OutputStream os = exchange.getResponseBody()) {
            os.write(bytes);
        }
    }

    private void sendPlainText(HttpExchange exchange, int status, String text) throws IOException {
        byte[] bytes = text.getBytes(StandardCharsets.UTF_8);
        exchange.getResponseHeaders().add("Content-Type", "text/plain; charset=utf-8");
        exchange.sendResponseHeaders(status, bytes.length);
        try (OutputStream os = exchange.getResponseBody()) {
            os.write(bytes);
        }
        exchange.close();
    }

    private String normalizePath(String path) {
        return path.startsWith("/") ? path : "/" + path;
    }

    private String joinPath(String base, String suffix) {
        String b = base.endsWith("/") ? base.substring(0, base.length() - 1) : base;
        return b + "/" + suffix;
    }

    private String queryParam(String query, String name, String def) {
        if (query == null) {
            return def;
        }
        for (String pair : query.split("&")) {
            int idx = pair.indexOf('=');
            if (idx > 0 && pair.substring(0, idx).equals(name)) {
                return decode(pair.substring(idx + 1));
            }
        }
        return def;
    }

    private String extract(Pattern pattern, String body) {
        Matcher matcher = pattern.matcher(body);
        return matcher.find() ? matcher.group(1) : null;
    }

    private String decode(String value) {
        return value == null ? null : java.net.URLDecoder.decode(value, StandardCharsets.UTF_8);
    }

    private String encode(String value) {
        return java.net.URLEncoder.encode(value, StandardCharsets.UTF_8);
    }
}
