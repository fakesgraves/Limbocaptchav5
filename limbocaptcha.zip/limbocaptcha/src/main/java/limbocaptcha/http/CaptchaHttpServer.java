package limbocaptcha.http;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;
import limbocaptcha.config.PluginConfig;
import limbocaptcha.database.CaptchaRecordDao;
import limbocaptcha.recaptcha.RecaptchaVerifier;
import limbocaptcha.session.CaptchaSession;
import limbocaptcha.session.CaptchaSessionManager;

import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.Executors;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Единственный встроенный HTTP-сервер плагина (на базе штатного
 * com.sun.net.httpserver из JDK, без внешних веб-фреймворков). Делает две вещи:
 * <p>
 * 1. GET {web.path} - отдаёт HTML-страницу с виджетом Google reCAPTCHA v2,
 *    целиком сгенерированную {@link CaptchaPageRenderer} из config.yml.
 *    Игрок получает ссылку именно сюда в чате Minecraft.
 * <p>
 * 2. POST {web.verify-path} - принимает от этой же страницы ответ виджета
 *    (g-recaptcha-response), проверяет его через Google siteverify и,
 *    при успехе, передаёт игрока дальше на авторизацию LimboAuth.
 * <p>
 * Никакого стороннего сайта/хостинга не требуется - и страница, и API живут
 * в одном месте, настраиваются одним config.yml.
 */
public final class CaptchaHttpServer {

    private static final Pattern TOKEN_PATTERN = Pattern.compile("token=([^&]+)");
    private static final Pattern RESPONSE_PATTERN = Pattern.compile("g-recaptcha-response=([^&]+)");

    private final PluginConfig config;
    private final CaptchaSessionManager sessionManager;
    private final RecaptchaVerifier verifier;
    private final CaptchaRecordDao dao;
    private final CaptchaPageRenderer pageRenderer;
    private final Logger logger;

    private HttpServer server;

    public CaptchaHttpServer(PluginConfig config, CaptchaSessionManager sessionManager,
                              RecaptchaVerifier verifier, CaptchaRecordDao dao, Logger logger) {
        this.config = config;
        this.sessionManager = sessionManager;
        this.verifier = verifier;
        this.dao = dao;
        this.logger = logger;
        this.pageRenderer = new CaptchaPageRenderer(config);
    }

    public void start() throws IOException {
        this.server = HttpServer.create(
                new InetSocketAddress(this.config.web.bindAddress, this.config.web.port), 0);
        this.server.setExecutor(Executors.newCachedThreadPool());

        String pagePath = normalizePath(this.config.web.path);
        String verifyPath = normalizePath(this.config.web.verifyPath);

        this.server.createContext(pagePath, this::handlePage);
        this.server.createContext(verifyPath, this::handleVerify);
        this.server.start();

        this.logger.info("LimboCaptcha веб-сервер запущен на "
                + this.config.web.bindAddress + ":" + this.config.web.port
                + " (страница: " + pagePath + ", API: " + verifyPath + ")");
    }

    public void stop() {
        if (this.server != null) {
            this.server.stop(0);
        }
    }

    // ---------------------------------------------------------------------
    // GET: страница капчи
    // ---------------------------------------------------------------------

    private void handlePage(HttpExchange exchange) {
        try {
            if (!"GET".equalsIgnoreCase(exchange.getRequestMethod())) {
                sendHtml(exchange, 405, "<h1>405 Method Not Allowed</h1>");
                return;
            }

            String token = queryParam(exchange.getRequestURI().getQuery(), "token");
            CaptchaSession session = token != null ? this.sessionManager.getByToken(token) : null;

            boolean invalid = (token == null) || (session == null) || session.isCompleted();
            String html = this.pageRenderer.render(token == null ? "" : token, invalid);

            sendHtml(exchange, 200, html);
        } catch (Exception e) {
            this.logger.warning("Ошибка при отдаче страницы капчи: " + e.getMessage());
            try {
                sendHtml(exchange, 500, "<h1>500 Internal Server Error</h1>");
            } catch (IOException ignored) {
                // соединение уже могло быть разорвано
            }
        } finally {
            exchange.close();
        }
    }

    // ---------------------------------------------------------------------
    // POST: приём результата капчи
    // ---------------------------------------------------------------------

    private void handleVerify(HttpExchange exchange) {
        try {
            applyCors(exchange);

            if ("OPTIONS".equalsIgnoreCase(exchange.getRequestMethod())) {
                sendJson(exchange, 204, "{}");
                return;
            }

            if (!"POST".equalsIgnoreCase(exchange.getRequestMethod())) {
                sendJson(exchange, 405, jsonError("method_not_allowed", "Метод не поддерживается."));
                return;
            }

            String body = new String(exchange.getRequestBody().readAllBytes(), StandardCharsets.UTF_8);
            String token = extract(TOKEN_PATTERN, body);
            String recaptchaResponse = decode(extract(RESPONSE_PATTERN, body));

            if (token == null || token.isBlank()) {
                sendJson(exchange, 400, jsonError("missing_token", "Отсутствует токен."));
                return;
            }

            CaptchaSession session = this.sessionManager.getByToken(token);
            if (session == null || session.isCompleted()) {
                sendJson(exchange, 404, jsonError("unknown_or_completed_session",
                        this.config.page.invalidLinkText));
                return;
            }

            String remoteIp = exchange.getRemoteAddress() != null
                    ? exchange.getRemoteAddress().getAddress().getHostAddress() : null;

            this.verifier.verify(recaptchaResponse, remoteIp).thenAccept(success -> {
                try {
                    if (success) {
                        if (this.dao != null) {
                            this.dao.markSuccess(token);
                        }
                        session.succeed();
                        sendJson(exchange, 200, "{\"ok\":true}");
                    } else {
                        if (this.dao != null) {
                            this.dao.markFailed(token);
                        }
                        session.fail("kick-failed");
                        this.sessionManager.removeByToken(token);
                        sendJson(exchange, 200, jsonError("captcha_failed", this.config.page.failedText));
                    }
                } catch (IOException e) {
                    this.logger.warning("Ошибка отправки HTTP-ответа: " + e.getMessage());
                } finally {
                    exchange.close();
                }
            });
        } catch (Exception e) {
            this.logger.warning("Ошибка обработки запроса капчи: " + e.getMessage());
            try {
                sendJson(exchange, 500, jsonError("internal_error", "Внутренняя ошибка сервера."));
            } catch (IOException ignored) {
                // соединение уже могло быть разорвано
            } finally {
                exchange.close();
            }
        }
    }

    // ---------------------------------------------------------------------
    // Утилиты
    // ---------------------------------------------------------------------

    private void applyCors(HttpExchange exchange) {
        exchange.getResponseHeaders().add("Access-Control-Allow-Origin", this.config.web.corsOrigin);
        exchange.getResponseHeaders().add("Access-Control-Allow-Methods", "POST, OPTIONS");
        exchange.getResponseHeaders().add("Access-Control-Allow-Headers", "Content-Type");
    }

    private void sendHtml(HttpExchange exchange, int status, String html) throws IOException {
        byte[] bytes = html.getBytes(StandardCharsets.UTF_8);
        exchange.getResponseHeaders().add("Content-Type", "text/html; charset=utf-8");
        exchange.sendResponseHeaders(status, bytes.length);
        try (OutputStream os = exchange.getResponseBody()) {
            os.write(bytes);
        }
    }

    private void sendJson(HttpExchange exchange, int status, String json) throws IOException {
        byte[] bytes = json.getBytes(StandardCharsets.UTF_8);
        exchange.getResponseHeaders().add("Content-Type", "application/json; charset=utf-8");
        exchange.sendResponseHeaders(status, bytes.length);
        try (OutputStream os = exchange.getResponseBody()) {
            os.write(bytes);
        }
    }

    private String jsonError(String code, String message) {
        return "{\"ok\":false,\"error\":\"" + code + "\",\"message\":\"" + jsonEscape(message) + "\"}";
    }

    private String jsonEscape(String value) {
        return value == null ? "" : value.replace("\\", "\\\\").replace("\"", "\\\"")
                .replace("\n", "\\n").replace("\r", "");
    }

    private String normalizePath(String path) {
        return path.startsWith("/") ? path : "/" + path;
    }

    private String queryParam(String query, String name) {
        if (query == null) {
            return null;
        }
        for (String pair : query.split("&")) {
            int idx = pair.indexOf('=');
            if (idx > 0 && pair.substring(0, idx).equals(name)) {
                return decode(pair.substring(idx + 1));
            }
        }
        return null;
    }

    private String extract(Pattern pattern, String body) {
        Matcher matcher = pattern.matcher(body);
        return matcher.find() ? matcher.group(1) : null;
    }

    private String decode(String value) {
        return value == null ? null : java.net.URLDecoder.decode(value, StandardCharsets.UTF_8);
    }
}
