package limbocaptcha.http;

import limbocaptcha.config.PluginConfig;

/**
 * Собирает самодостаточную HTML-страницу с виджетом Google reCAPTCHA v2
 * целиком из значений config.yml (секция {@code page}) - владелец сервера
 * настраивает внешний вид страницы (тексты, цвета, логотип, ссылку на сайт)
 * ИСКЛЮЧИТЕЛЬНО через конфиг плагина, не трогая HTML/CSS/JS вручную.
 * <p>
 * Страница отдаётся тем же встроенным HTTP-сервером, что принимает
 * подтверждение капчи (см. {@link CaptchaHttpServer}) - отдельный сайт/хостинг
 * не требуется.
 */
public final class CaptchaPageRenderer {

    private final PluginConfig config;

    public CaptchaPageRenderer(PluginConfig config) {
        this.config = config;
    }

    /**
     * @param token   токен captcha-сессии из ссылки (?token=...)
     * @param invalid true, если токен не найден/просрочен - тогда сразу показывается
     *                страница "ссылка недействительна" без формы капчи
     */
    public String render(String token, boolean invalid) {
        PluginConfig.PageSection p = this.config.page;

        String logoBlock = p.logoUrl == null || p.logoUrl.isBlank()
                ? ""
                : "<div class=\"logo\"><img src=\"" + escapeAttr(p.logoUrl) + "\" alt=\"" + escapeAttr(p.serverName) + "\"></div>";

        String siteLinkBlock = p.siteUrl == null || p.siteUrl.isBlank()
                ? ""
                : "<a href=\"" + escapeAttr(p.siteUrl) + "\" class=\"site-link\">На сайт</a>";

        String verifyUrl = this.config.web.verifyPath.startsWith("/")
                ? this.config.web.verifyPath : "/" + this.config.web.verifyPath;

        String bodyContent;
        if (invalid) {
            bodyContent = renderInvalidBlock(p);
        } else {
            bodyContent = renderCaptchaBlock(p, token, verifyUrl);
        }

        return "<!DOCTYPE html>\n"
                + "<html lang=\"ru\">\n"
                + "<head>\n"
                + "<meta charset=\"UTF-8\">\n"
                + "<meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">\n"
                + "<title>" + escapeHtml(p.serverName) + " — " + escapeHtml(p.title) + "</title>\n"
                + (invalid ? "" : "<script src=\"https://www.google.com/recaptcha/api.js\" async defer></script>\n")
                + "<style>" + css(p) + "</style>\n"
                + "</head>\n"
                + "<body>\n"
                + "<div class=\"page\">\n"
                + "<div class=\"card\">\n"
                + logoBlock
                + bodyContent
                + "<div class=\"divider\"></div>\n"
                + "<div class=\"footer\">" + escapeHtml(p.serverName) + siteLinkBlock + "</div>\n"
                + "</div>\n"
                + "</div>\n"
                + "</body>\n"
                + "</html>\n";
    }

    private String renderInvalidBlock(PluginConfig.PageSection p) {
        return "<div class=\"title\">" + escapeHtml(p.failedTitle) + "</div>\n"
                + "<div class=\"message error-text\">" + escapeHtml(p.invalidLinkText) + "</div>\n";
    }

    private String renderCaptchaBlock(PluginConfig.PageSection p, String token, String verifyUrl) {
        return "<div id=\"formPage\">\n"
                + "  <div class=\"title\">" + escapeHtml(p.title) + "</div>\n"
                + "  <div class=\"subtitle\">" + escapeHtml(p.subtitle) + "</div>\n"
                + "  <div class=\"widget-wrap\"><div class=\"g-recaptcha\" data-sitekey=\""
                + escapeAttr(this.config.recaptcha.siteKey) + "\"></div></div>\n"
                + "  <button id=\"verifyBtn\" class=\"btn\">" + escapeHtml(p.buttonText) + "</button>\n"
                + "  <div id=\"statusMessage\" class=\"status\"></div>\n"
                + "</div>\n"
                + "<div id=\"successPage\" class=\"hidden\">\n"
                + "  <div class=\"title\">" + escapeHtml(p.successTitle) + "</div>\n"
                + "  <div class=\"message success-text\">" + escapeHtml(p.successText) + "</div>\n"
                + "</div>\n"
                + "<div id=\"failedPage\" class=\"hidden\">\n"
                + "  <div class=\"title\">" + escapeHtml(p.failedTitle) + "</div>\n"
                + "  <div id=\"failedMessage\" class=\"message error-text\">" + escapeHtml(p.failedText) + "</div>\n"
                + "  <button id=\"retryBtn\" class=\"btn btn-error\">Попробовать снова</button>\n"
                + "</div>\n"
                + "<script>" + js(token, verifyUrl) + "</script>\n";
    }

    private String css(PluginConfig.PageSection p) {
        return "*{margin:0;padding:0;box-sizing:border-box}"
                + "body{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;"
                + "background:#f4f4f6;min-height:100vh;display:flex;justify-content:center;align-items:center;color:#1a1a2e}"
                + ".page{width:100%;max-width:440px;padding:20px}"
                + ".card{background:#fff;border-radius:24px;padding:40px 30px;border:1px solid #e5e7eb;"
                + "box-shadow:0 1px 3px rgba(0,0,0,.06);text-align:center}"
                + ".logo img{width:64px;height:64px;border-radius:16px;margin-bottom:20px}"
                + ".title{font-size:22px;font-weight:700;margin-bottom:12px}"
                + ".subtitle{font-size:14px;color:#6b7280;line-height:1.5;margin-bottom:26px}"
                + ".message{font-size:14px;color:#6b7280;line-height:1.6;margin:16px 0}"
                + ".widget-wrap{display:flex;justify-content:center;margin-bottom:18px;min-height:78px}"
                + ".btn{display:inline-block;background:" + p.accentColor + ";color:#fff;border:1px solid "
                + p.accentColor + ";padding:12px 32px;border-radius:12px;font-size:15px;font-weight:600;"
                + "cursor:pointer;margin-top:6px;transition:.2s}"
                + ".btn:hover:not(:disabled){filter:brightness(0.92)}"
                + ".btn:disabled{opacity:.6;cursor:not-allowed}"
                + ".btn-error{background:" + p.errorColor + ";border-color:" + p.errorColor + "}"
                + ".status{font-size:13px;margin-top:12px;min-height:18px;color:" + p.successColor + "}"
                + ".status.error{color:" + p.errorColor + "}"
                + ".error-text{color:" + p.errorColor + "}"
                + ".success-text{color:" + p.successColor + "}"
                + ".divider{height:1px;background:#e5e7eb;margin:26px 0 16px}"
                + ".footer{font-size:13px;color:#9ca3af}"
                + ".site-link{color:" + p.accentColor + ";text-decoration:none;margin-left:8px}"
                + ".hidden{display:none}";
    }

    private String js(String token, String verifyUrl) {
        // Токен и URL уже проверены/сгенерированы сервером - безопасно подставлять напрямую.
        return "const TOKEN=" + jsString(token) + ";"
                + "const VERIFY_URL=" + jsString(verifyUrl) + ";"
                + "const formPage=document.getElementById('formPage');"
                + "const successPage=document.getElementById('successPage');"
                + "const failedPage=document.getElementById('failedPage');"
                + "const failedMessage=document.getElementById('failedMessage');"
                + "const statusEl=document.getElementById('statusMessage');"
                + "const verifyBtn=document.getElementById('verifyBtn');"
                + "const retryBtn=document.getElementById('retryBtn');"
                + "function show(el){[formPage,successPage,failedPage].forEach(e=>e.classList.add('hidden'));el.classList.remove('hidden');}"
                + "function setStatus(t,cls){statusEl.textContent=t;statusEl.className='status'+(cls?' '+cls:'');}"
                + "verifyBtn.addEventListener('click',function(){"
                + "  const resp=grecaptcha.getResponse();"
                + "  if(!resp){setStatus('Сначала пройдите проверку выше.','error');return;}"
                + "  verifyBtn.disabled=true;setStatus('Проверяем...','');"
                + "  const body=new URLSearchParams();body.set('token',TOKEN);body.set('g-recaptcha-response',resp);"
                + "  fetch(VERIFY_URL,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:body.toString()})"
                + "    .then(r=>r.json())"
                + "    .then(data=>{"
                + "      if(data.ok){show(successPage);}"
                + "      else{if(data.message){failedMessage.textContent=data.message;}show(failedPage);}"
                + "    })"
                + "    .catch(()=>{setStatus('Не удалось связаться с сервером. Попробуйте ещё раз.','error');})"
                + "    .finally(()=>{verifyBtn.disabled=false;grecaptcha.reset();});"
                + "});"
                + "if(retryBtn){retryBtn.addEventListener('click',function(){show(formPage);setStatus('','');});}";
    }

    private static String jsString(String value) {
        String escaped = value == null ? "" : value.replace("\\", "\\\\").replace("'", "\\'");
        return "'" + escaped + "'";
    }

    private static String escapeHtml(String value) {
        if (value == null) {
            return "";
        }
        return value.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
    }

    private static String escapeAttr(String value) {
        return escapeHtml(value).replace("\"", "&quot;");
    }
}
