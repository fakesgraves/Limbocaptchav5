package limbocaptcha.http;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Map;
import java.util.logging.Logger;

/**
 * При первом запуске копирует дефолтные HTML-шаблоны (captcha.html,
 * success.html, failed.html) из ресурсов jar'а в plugins/limbocaptcha/web/,
 * если их там ещё нет - точно так же, как ConfigManager поступает с config.yml.
 * <p>
 * Дальше каждый шаблон читается заново с диска при каждом запросе (файлы
 * маленькие, чтения раз в запрос не создают заметной нагрузки), поэтому
 * владелец сервера может редактировать эти файлы прямо во время работы
 * прокси - изменения применяются сразу, без перезапуска.
 */
public final class WebTemplateManager {

    private static final String[] DEFAULT_TEMPLATES = {"captcha.html", "success.html", "failed.html"};

    private final Path webDirectory;
    private final Logger logger;

    public WebTemplateManager(Path dataDirectory, Logger logger) {
        this.webDirectory = dataDirectory.resolve("web");
        this.logger = logger;
    }

    /** Копирует дефолтные шаблоны, если их ещё нет на диске. Вызывать один раз при старте. */
    public void ensureDefaultsExist() throws IOException {
        Files.createDirectories(this.webDirectory);

        for (String fileName : DEFAULT_TEMPLATES) {
            Path target = this.webDirectory.resolve(fileName);
            if (Files.exists(target)) {
                continue;
            }

            try (InputStream in = getClass().getClassLoader().getResourceAsStream("web/" + fileName)) {
                if (in == null) {
                    throw new IllegalStateException("Не найден дефолтный шаблон web/" + fileName + " внутри jar");
                }
                Files.copy(in, target);
                this.logger.info("Создан дефолтный шаблон: " + target);
            }
        }
    }

    /**
     * Читает шаблон с диска и подставляет плейсхолдеры вида {{NAME}}.
     * Если в файле плейсхолдера нет - подстановка для него просто не происходит,
     * это не ошибка (админ мог сознательно упростить страницу).
     */
    public String render(String fileName, Map<String, String> placeholders) throws IOException {
        Path file = this.webDirectory.resolve(fileName);
        String content = Files.readString(file, StandardCharsets.UTF_8);

        for (Map.Entry<String, String> entry : placeholders.entrySet()) {
            content = content.replace("{{" + entry.getKey() + "}}", entry.getValue() == null ? "" : entry.getValue());
        }
        return content;
    }
}
