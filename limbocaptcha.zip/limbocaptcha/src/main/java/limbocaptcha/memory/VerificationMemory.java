package limbocaptcha.memory;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.Map;
import java.util.Properties;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Logger;

/**
 * Лёгкая замена базе данных: помнит, когда игрок в последний раз успешно
 * прошёл капчу, и хранит это в единственном файле
 * plugins/limbocaptcha/verified-players.dat (обычный Properties-формат
 * "uuid=timestamp", по одной строке на игрока).
 * <p>
 * Если с момента последнего успешного прохождения не прошло больше
 * remember.hours (config.yml) - капча повторно не показывается, игрок сразу
 * передаётся на авторизацию LimboAuth.
 */
public final class VerificationMemory {

    private final Path storageFile;
    private final Logger logger;
    private final Map<UUID, Long> lastVerifiedAt = new ConcurrentHashMap<>();

    public VerificationMemory(Path dataDirectory, Logger logger) {
        this.storageFile = dataDirectory.resolve("verified-players.dat");
        this.logger = logger;
    }

    /** Загружает данные с диска. Вызывать один раз при старте плагина. */
    public synchronized void load() {
        if (!Files.exists(this.storageFile)) {
            return;
        }

        Properties properties = new Properties();
        try (InputStream in = Files.newInputStream(this.storageFile)) {
            properties.load(in);
        } catch (IOException e) {
            this.logger.warning("Не удалось прочитать verified-players.dat: " + e.getMessage());
            return;
        }

        int loaded = 0;
        for (String key : properties.stringPropertyNames()) {
            try {
                UUID uuid = UUID.fromString(key);
                long timestamp = Long.parseLong(properties.getProperty(key));
                this.lastVerifiedAt.put(uuid, timestamp);
                loaded++;
            } catch (IllegalArgumentException e) {
                // Битая строка в файле - просто пропускаем её, не роняем загрузку остальных
                this.logger.warning("Пропущена некорректная запись в verified-players.dat: " + key);
            }
        }
        this.logger.info("Загружено " + loaded + " записей о пройденной капче.");
    }

    /** Сохраняет текущее состояние на диск. Безопасно вызывать периодически и при остановке плагина. */
    public synchronized void save() {
        Properties properties = new Properties();
        for (Map.Entry<UUID, Long> entry : this.lastVerifiedAt.entrySet()) {
            properties.setProperty(entry.getKey().toString(), String.valueOf(entry.getValue()));
        }

        Path tmpFile = this.storageFile.resolveSibling(this.storageFile.getFileName() + ".tmp");
        try (OutputStream out = Files.newOutputStream(tmpFile)) {
            properties.store(out, "LimboCaptcha - UUID игрока -> время (мс) последнего успешного прохождения капчи");
            // Атомарная замена файла, чтобы при падении сервера посреди записи
            // не остаться с повреждённым/пустым verified-players.dat
            Files.move(tmpFile, this.storageFile, StandardCopyOption.REPLACE_EXISTING);
        } catch (IOException e) {
            this.logger.warning("Не удалось сохранить verified-players.dat: " + e.getMessage());
        }
    }

    /** Отмечает игрока прошедшим капчу прямо сейчас. */
    public void markVerified(UUID uuid) {
        this.lastVerifiedAt.put(uuid, System.currentTimeMillis());
    }

    /** true, если игрок проходил капчу не позднее remember.hours часов назад. */
    public boolean isRecentlyVerified(UUID uuid, long hours) {
        Long timestamp = this.lastVerifiedAt.get(uuid);
        if (timestamp == null) {
            return false;
        }
        long maxAgeMillis = hours * 60L * 60L * 1000L;
        return System.currentTimeMillis() - timestamp <= maxAgeMillis;
    }

    /** Убирает из памяти записи старше maxAgeHours - вызывать периодически, чтобы файл не рос бесконечно. */
    public void purgeOlderThan(long maxAgeHours) {
        long threshold = System.currentTimeMillis() - (maxAgeHours * 60L * 60L * 1000L);
        this.lastVerifiedAt.entrySet().removeIf(entry -> entry.getValue() < threshold);
    }
}
