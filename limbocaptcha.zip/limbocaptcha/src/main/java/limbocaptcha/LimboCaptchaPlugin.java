package limbocaptcha;

import com.google.inject.Inject;
import com.velocitypowered.api.event.Subscribe;
import com.velocitypowered.api.event.proxy.ProxyInitializeEvent;
import com.velocitypowered.api.event.proxy.ProxyShutdownEvent;
import com.velocitypowered.api.plugin.Dependency;
import com.velocitypowered.api.plugin.Plugin;
import com.velocitypowered.api.plugin.annotation.DataDirectory;
import com.velocitypowered.api.proxy.ProxyServer;
import limbocaptcha.config.ConfigManager;
import limbocaptcha.config.PluginConfig;
import limbocaptcha.http.CaptchaHttpServer;
import limbocaptcha.http.WebTemplateManager;
import limbocaptcha.listener.LimboRegisterListener;
import limbocaptcha.memory.VerificationMemory;
import limbocaptcha.recaptcha.RecaptchaVerifier;
import limbocaptcha.session.CaptchaSessionManager;
import net.elytrium.limboapi.api.LimboFactory;
import org.slf4j.Logger;

import java.io.IOException;
import java.nio.file.Path;
import java.util.concurrent.TimeUnit;

@Plugin(
        id = "limbocaptcha",
        name = "LimboCaptcha",
        version = "1.0.0",
        description = "Self-hosted reCAPTCHA v2 верификация перед авторизацией LimboAuth",
        authors = {"YourName"},
        dependencies = {
                @Dependency(id = "limboapi"),
                @Dependency(id = "limboauth", optional = true)
        }
)
public class LimboCaptchaPlugin {

    private final ProxyServer server;
    private final Logger logger;
    private final Path dataDirectory;
    private final java.util.logging.Logger julLogger = java.util.logging.Logger.getLogger("LimboCaptcha");

    private PluginConfig pluginConfig;
    private CaptchaSessionManager sessionManager;
    private CaptchaHttpServer httpServer;
    private RecaptchaVerifier recaptchaVerifier;
    private LimboFactory limboFactory;
    private VerificationMemory verificationMemory;
    private WebTemplateManager webTemplateManager;

    @Inject
    public LimboCaptchaPlugin(ProxyServer server, Logger logger, @DataDirectory Path dataDirectory) {
        this.server = server;
        this.logger = logger;
        this.dataDirectory = dataDirectory;
    }

    @Subscribe
    public void onProxyInitialize(ProxyInitializeEvent event) {
        this.pluginConfig = new ConfigManager(this.dataDirectory, this.julLogger).load();

        this.limboFactory = this.server.getPluginManager().getPlugin("limboapi")
                .flatMap(container -> container.getInstance())
                .map(instance -> (LimboFactory) instance)
                .orElse(null);

        if (this.limboFactory == null) {
            this.logger.error("Плагин LimboAPI не найден! LimboCaptcha не может работать без него. "
                    + "Установите LimboAPI и перезапустите прокси.");
            return;
        }

        // ---- "Память" о недавно пройденной капче (замена БД, файл на диске) ----
        this.verificationMemory = new VerificationMemory(this.dataDirectory, this.julLogger);
        this.verificationMemory.load();

        // ---- HTML-шаблоны страниц (копируем дефолты, если их ещё нет) ----
        this.webTemplateManager = new WebTemplateManager(this.dataDirectory, this.julLogger);
        try {
            this.webTemplateManager.ensureDefaultsExist();
        } catch (IOException e) {
            this.logger.error("Не удалось создать дефолтные HTML-шаблоны в папке web/", e);
        }

        this.sessionManager = new CaptchaSessionManager();
        this.recaptchaVerifier = new RecaptchaVerifier(
                this.pluginConfig.recaptcha.verifyUrl, this.pluginConfig.recaptcha.secretKey, this.julLogger);

        // ---- Встроенный веб-сервер: страницы + API проверки, всё внутри плагина ----
        this.httpServer = new CaptchaHttpServer(
                this.pluginConfig, this.sessionManager, this.recaptchaVerifier,
                this.verificationMemory, this.webTemplateManager, this.julLogger);
        try {
            this.httpServer.start();
        } catch (IOException e) {
            this.logger.error("Не удалось запустить встроенный веб-сервер LimboCaptcha. Проверьте, "
                    + "что порт web.port из config.yml свободен.", e);
        }

        this.server.getEventManager().register(this, new LimboRegisterListener(this, this.limboFactory));

        // Периодическая чистка просроченных captcha-сессий в памяти
        this.server.getScheduler().buildTask(this, () -> this.sessionManager.purgeExpired(
                        this.pluginConfig.tokenTtlSeconds, null))
                .repeat(10, TimeUnit.SECONDS)
                .delay(10, TimeUnit.SECONDS)
                .schedule();

        // Периодическое сохранение verified-players.dat на диск + чистка устаревших записей
        // (держим с запасом x3 от remember.hours, чтобы не тереть данные слишком рано
        // из-за пограничных случаев вокруг самой границы окна)
        this.server.getScheduler().buildTask(this, () -> {
                    long keepHours = Math.max(1, this.pluginConfig.remember.hours) * 3;
                    this.verificationMemory.purgeOlderThan(keepHours);
                    this.verificationMemory.save();
                })
                .repeat(5, TimeUnit.MINUTES)
                .delay(5, TimeUnit.MINUTES)
                .schedule();

        this.logger.info("LimboCaptcha успешно запущен. Страница капчи: "
                + this.pluginConfig.buildCaptchaLink("<token>"));
    }

    @Subscribe
    public void onProxyShutdown(ProxyShutdownEvent event) {
        if (this.httpServer != null) {
            this.httpServer.stop();
        }
        if (this.verificationMemory != null) {
            this.verificationMemory.save();
        }
    }

    public ProxyServer getServer() {
        return this.server;
    }

    public PluginConfig getPluginConfig() {
        return this.pluginConfig;
    }

    public CaptchaSessionManager getSessionManager() {
        return this.sessionManager;
    }

    public VerificationMemory getVerificationMemory() {
        return this.verificationMemory;
    }
}
