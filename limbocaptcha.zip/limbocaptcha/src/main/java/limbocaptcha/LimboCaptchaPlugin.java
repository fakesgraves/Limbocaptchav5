package limbocaptcha;

import com.google.inject.Inject;
import com.velocitypowered.api.event.Subscribe;
import com.velocitypowered.api.event.proxy.ProxyInitializeEvent;
import com.velocitypowered.api.event.proxy.ProxyShutdownEvent;
import com.velocitypowered.api.plugin.Dependency;
import com.velocitypowered.api.plugin.Plugin;
import com.velocitypowered.api.plugin.annotation.DataDirectory;
import com.velocitypowered.api.proxy.ProxyServer;
import limbocaptcha.config.ConfigManager;
import limbocaptcha.config.PluginConfig;
import limbocaptcha.database.CaptchaRecordDao;
import limbocaptcha.database.DatabaseManager;
import limbocaptcha.http.CaptchaHttpServer;
import limbocaptcha.listener.LimboRegisterListener;
import limbocaptcha.recaptcha.RecaptchaVerifier;
import limbocaptcha.session.CaptchaSessionManager;
import net.elytrium.limboapi.api.LimboFactory;
import org.slf4j.Logger;

import java.io.IOException;
import java.nio.file.Path;
import java.sql.SQLException;
import java.util.concurrent.TimeUnit;

@Plugin(
        id = "limbocaptcha",
        name = "LimboCaptcha",
        version = "1.0.0",
        description = "Self-hosted reCAPTCHA v2 верификация перед авторизацией LimboAuth",
        authors = {"YourName"},
        dependencies = {
                @Dependency(id = "limboapi"),
                @Dependency(id = "limboauth", optional = true)
        }
)
public class LimboCaptchaPlugin {

    private final ProxyServer server;
    private final Logger logger;
    private final Path dataDirectory;
    private final java.util.logging.Logger julLogger = java.util.logging.Logger.getLogger("LimboCaptcha");

    private PluginConfig pluginConfig;
    private CaptchaSessionManager sessionManager;
    private CaptchaHttpServer httpServer;
    private RecaptchaVerifier recaptchaVerifier;
    private LimboFactory limboFactory;

    private DatabaseManager databaseManager;
    private CaptchaRecordDao captchaDao;

    @Inject
    public LimboCaptchaPlugin(ProxyServer server, Logger logger, @DataDirectory Path dataDirectory) {
        this.server = server;
        this.logger = logger;
        this.dataDirectory = dataDirectory;
    }

    @Subscribe
    public void onProxyInitialize(ProxyInitializeEvent event) {
        this.pluginConfig = new ConfigManager(this.dataDirectory, this.julLogger).load();

        this.limboFactory = this.server.getPluginManager().getPlugin("limboapi")
                .flatMap(container -> container.getInstance())
                .map(instance -> (LimboFactory) instance)
                .orElse(null);

        if (this.limboFactory == null) {
            this.logger.error("Плагин LimboAPI не найден! LimboCaptcha не может работать без него. "
                    + "Установите LimboAPI и перезапустите прокси.");
            return;
        }

        // ---- База данных (история всех проверок капчи) ----
        this.databaseManager = new DatabaseManager(this.pluginConfig, this.dataDirectory, this.julLogger);
        try {
            this.databaseManager.connect();
            this.captchaDao = new CaptchaRecordDao(
                    this.databaseManager.getDataSource(), this.databaseManager.getTableName(), this.julLogger);
        } catch (SQLException e) {
            this.logger.error("Не удалось подключиться к БД LimboCaptcha. Плагин продолжит работу "
                    + "БЕЗ сохранения истории проверок.", e);
            this.captchaDao = null;
        }

        this.sessionManager = new CaptchaSessionManager();
        this.recaptchaVerifier = new RecaptchaVerifier(
                this.pluginConfig.recaptcha.verifyUrl, this.pluginConfig.recaptcha.secretKey, this.julLogger);

        // ---- Встроенный веб-сервер: страница капчи + API проверки, всё внутри плагина ----
        this.httpServer = new CaptchaHttpServer(
                this.pluginConfig, this.sessionManager, this.recaptchaVerifier, this.captchaDao, this.julLogger);
        try {
            this.httpServer.start();
        } catch (IOException e) {
            this.logger.error("Не удалось запустить встроенный веб-сервер LimboCaptcha. Проверьте, "
                    + "что порт web.port из config.yml свободен.", e);
        }

        this.server.getEventManager().register(this, new LimboRegisterListener(this, this.limboFactory));

        // Периодическая чистка просроченных captcha-сессий (память + БД)
        this.server.getScheduler().buildTask(this, this::purgeExpiredSessions)
                .repeat(10, TimeUnit.SECONDS)
                .delay(10, TimeUnit.SECONDS)
                .schedule();

        this.logger.info("LimboCaptcha успешно запущен. Страница капчи: "
                + this.pluginConfig.buildCaptchaLink("<token>"));
    }

    private void purgeExpiredSessions() {
        this.sessionManager.purgeExpired(this.pluginConfig.tokenTtlSeconds, token -> {
            if (this.captchaDao != null) {
                this.captchaDao.markExpired(token);
            }
        });

        // "Осиротевшие" записи в БД без живой сессии в памяти (например, после
        // перезапуска прокси, пока игрок ждал в captcha-лимбо) - просто помечаем
        // для истории, кикать уже некого.
        if (this.captchaDao != null) {
            for (String token : this.captchaDao.findStalePending(this.pluginConfig.tokenTtlSeconds)) {
                this.captchaDao.markExpired(token);
            }
        }
    }

    @Subscribe
    public void onProxyShutdown(ProxyShutdownEvent event) {
        if (this.httpServer != null) {
            this.httpServer.stop();
        }
        if (this.databaseManager != null) {
            this.databaseManager.close();
        }
    }

    public ProxyServer getServer() {
        return this.server;
    }

    public PluginConfig getPluginConfig() {
        return this.pluginConfig;
    }

    public CaptchaSessionManager getSessionManager() {
        return this.sessionManager;
    }

    public CaptchaRecordDao getCaptchaDao() {
        return this.captchaDao;
    }
}
