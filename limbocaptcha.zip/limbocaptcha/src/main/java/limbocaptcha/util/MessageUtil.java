package limbocaptcha.util;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;

/**
 * Небольшая обёртка над Adventure MiniMessage для рендера сообщений из config.yml
 * (поддерживает теги вида <green>, <click:open_url:'...'>, <newline> и т.д.)
 */
public final class MessageUtil {

    private static final MiniMessage MINI_MESSAGE = MiniMessage.miniMessage();

    private MessageUtil() {
    }

    public static Component render(String raw) {
        if (raw == null) {
            return Component.empty();
        }
        return MINI_MESSAGE.deserialize(raw);
    }

    public static Component render(String raw, String placeholder, String value) {
        if (raw == null) {
            return Component.empty();
        }
        String replaced = raw.replace(placeholder, value);
        return MINI_MESSAGE.deserialize(replaced);
    }
}
