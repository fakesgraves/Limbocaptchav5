package limbocaptcha.database;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import limbocaptcha.config.PluginConfig;

import java.nio.file.Path;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Logger;

/**
 * Инициализирует пул соединений (SQLite по умолчанию, либо MySQL согласно
 * database.type в config.yml) и создаёт таблицу captcha_sessions, если её ещё нет.
 */
public final class DatabaseManager {

    private final PluginConfig config;
    private final Path dataDirectory;
    private final Logger logger;
    private final String tableName;
    private final boolean mysql;

    private HikariDataSource dataSource;

    public DatabaseManager(PluginConfig config, Path dataDirectory, Logger logger) {
        this.config = config;
        this.dataDirectory = dataDirectory;
        this.logger = logger;
        this.mysql = "mysql".equalsIgnoreCase(config.database.type);
        this.tableName = this.mysql
                ? config.database.mysql.tablePrefix + "captcha_sessions"
                : "captcha_sessions";
    }

    public void connect() throws SQLException {
        HikariConfig hikariConfig = new HikariConfig();
        hikariConfig.setMaximumPoolSize(Math.max(1, this.config.database.pool.maximumPoolSize));
        hikariConfig.setConnectionTimeout(Math.max(1000, this.config.database.pool.connectionTimeoutMs));
        hikariConfig.setPoolName("LimboCaptcha-Pool");

        if (this.mysql) {
            PluginConfig.MysqlSection mysqlCfg = this.config.database.mysql;
            String jdbcUrl = "jdbc:mysql://" + mysqlCfg.host + ":" + mysqlCfg.port + "/" + mysqlCfg.database
                    + "?useSSL=" + mysqlCfg.useSsl
                    + "&allowPublicKeyRetrieval=true&useUnicode=true&characterEncoding=utf8";
            hikariConfig.setJdbcUrl(jdbcUrl);
            hikariConfig.setUsername(mysqlCfg.username);
            hikariConfig.setPassword(mysqlCfg.password);
            hikariConfig.setDriverClassName("com.mysql.cj.jdbc.Driver");
        } else {
            Path dbFile = this.dataDirectory.resolve(this.config.database.sqlite.file);
            hikariConfig.setJdbcUrl("jdbc:sqlite:" + dbFile.toAbsolutePath());
            hikariConfig.setDriverClassName("org.sqlite.JDBC");
            hikariConfig.setMaximumPoolSize(1); // SQLite не любит параллельные записи
        }

        this.dataSource = new HikariDataSource(hikariConfig);
        createSchema();
        this.logger.info("Подключение к БД (" + (this.mysql ? "MySQL" : "SQLite") + ") установлено.");
    }

    private void createSchema() throws SQLException {
        String ddl = "CREATE TABLE IF NOT EXISTS " + this.tableName + " ("
                + "token VARCHAR(64) PRIMARY KEY, "
                + "player_uuid VARCHAR(36) NOT NULL, "
                + "player_name VARCHAR(32), "
                + "ip_address VARCHAR(64), "
                + "status VARCHAR(16) NOT NULL, "
                + "created_at BIGINT NOT NULL, "
                + "updated_at BIGINT NOT NULL"
                + ")";

        try (Connection connection = this.dataSource.getConnection();
             Statement statement = connection.createStatement()) {
            statement.execute(ddl);
            statement.execute("CREATE INDEX IF NOT EXISTS idx_" + this.tableName + "_status "
                    + "ON " + this.tableName + " (status)");
            statement.execute("CREATE INDEX IF NOT EXISTS idx_" + this.tableName + "_player "
                    + "ON " + this.tableName + " (player_uuid)");
        }
    }

    public HikariDataSource getDataSource() {
        return this.dataSource;
    }

    public String getTableName() {
        return this.tableName;
    }

    public void close() {
        if (this.dataSource != null) {
            this.dataSource.close();
        }
    }
}
