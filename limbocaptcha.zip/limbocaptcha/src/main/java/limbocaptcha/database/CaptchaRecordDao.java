package limbocaptcha.database;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;
import java.util.ArrayList;
import java.util.logging.Logger;

/**
 * Простой JDBC DAO (без ORM) для таблицы captcha_sessions - хранит историю
 * всех проверок капчи (для аудита/статистики).
 */
public final class CaptchaRecordDao {

    private final DataSource dataSource;
    private final String table;
    private final Logger logger;

    public CaptchaRecordDao(DataSource dataSource, String table, Logger logger) {
        this.dataSource = dataSource;
        this.table = table;
        this.logger = logger;
    }

    public void insertPending(String token, String playerUuid, String playerName, String ipAddress) {
        String sql = "INSERT INTO " + this.table
                + " (token, player_uuid, player_name, ip_address, status, created_at, updated_at) "
                + "VALUES (?, ?, ?, ?, 'PENDING', ?, ?)";

        long now = System.currentTimeMillis();
        try (Connection connection = this.dataSource.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, token);
            statement.setString(2, playerUuid);
            statement.setString(3, playerName);
            statement.setString(4, ipAddress);
            statement.setLong(5, now);
            statement.setLong(6, now);
            statement.executeUpdate();
        } catch (SQLException e) {
            this.logger.warning("Не удалось сохранить captcha-сессию в БД: " + e.getMessage());
        }
    }

    public void markSuccess(String token) {
        updateStatus(token, "SUCCESS");
    }

    public void markFailed(String token) {
        updateStatus(token, "FAILED");
    }

    public void markExpired(String token) {
        updateStatus(token, "EXPIRED");
    }

    private void updateStatus(String token, String newStatus) {
        String sql = "UPDATE " + this.table + " SET status = ?, updated_at = ? WHERE token = ?";
        try (Connection connection = this.dataSource.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, newStatus);
            statement.setLong(2, System.currentTimeMillis());
            statement.setString(3, token);
            statement.executeUpdate();
        } catch (SQLException e) {
            this.logger.warning("Не удалось обновить статус captcha-сессии в БД: " + e.getMessage());
        }
    }

    /** Удаляет старые завершённые записи (для очистки истории по расписанию, необязательно). */
    public void purgeOlderThan(long days) {
        String sql = "DELETE FROM " + this.table
                + " WHERE status IN ('SUCCESS', 'FAILED', 'EXPIRED') AND updated_at < ?";

        long threshold = System.currentTimeMillis() - (days * 24L * 60 * 60 * 1000);
        try (Connection connection = this.dataSource.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setLong(1, threshold);
            int deleted = statement.executeUpdate();
            if (deleted > 0) {
                this.logger.info("Очищено " + deleted + " старых записей captcha из БД.");
            }
        } catch (SQLException e) {
            this.logger.warning("Не удалось очистить старые записи captcha из БД: " + e.getMessage());
        }
    }

    /** Список токенов, которые пора считать истёкшими (для восстановления после рестарта прокси). */
    public List<String> findStalePending(long ttlSeconds) {
        String sql = "SELECT token FROM " + this.table + " WHERE status = 'PENDING' AND created_at < ?";
        long threshold = System.currentTimeMillis() - (ttlSeconds * 1000L);

        List<String> tokens = new ArrayList<>();
        try (Connection connection = this.dataSource.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setLong(1, threshold);
            try (var rs = statement.executeQuery()) {
                while (rs.next()) {
                    tokens.add(rs.getString("token"));
                }
            }
        } catch (SQLException e) {
            this.logger.warning("Не удалось получить список просроченных captcha-сессий: " + e.getMessage());
        }
        return tokens;
    }
}
