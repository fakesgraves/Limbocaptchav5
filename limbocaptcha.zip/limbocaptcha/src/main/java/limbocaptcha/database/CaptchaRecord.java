package limbocaptcha.database;

/**
 * Одна строка таблицы captcha_sessions - история попытки прохождения капчи
 * конкретным игроком (для аудита/статистики).
 */
public final class CaptchaRecord {

    public enum Status {
        PENDING, SUCCESS, FAILED, EXPIRED
    }

    private final String token;
    private final String playerUuid;
    private final String playerName;
    private final String ipAddress;
    private final Status status;
    private final long createdAt;
    private final long updatedAt;

    public CaptchaRecord(String token, String playerUuid, String playerName, String ipAddress,
                          Status status, long createdAt, long updatedAt) {
        this.token = token;
        this.playerUuid = playerUuid;
        this.playerName = playerName;
        this.ipAddress = ipAddress;
        this.status = status;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
    }

    public String getToken() {
        return this.token;
    }

    public String getPlayerUuid() {
        return this.playerUuid;
    }

    public String getPlayerName() {
        return this.playerName;
    }

    public String getIpAddress() {
        return this.ipAddress;
    }

    public Status getStatus() {
        return this.status;
    }

    public long getCreatedAt() {
        return this.createdAt;
    }

    public long getUpdatedAt() {
        return this.updatedAt;
    }
}
