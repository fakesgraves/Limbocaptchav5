package limbocaptcha.listener;

import com.velocitypowered.api.event.PostOrder;
import com.velocitypowered.api.event.Subscribe;
import com.velocitypowered.api.proxy.Player;
import limbocaptcha.LimboCaptchaPlugin;
import limbocaptcha.config.PluginConfig;
import limbocaptcha.limbo.CaptchaLimboHandler;
import limbocaptcha.session.CaptchaSession;
import limbocaptcha.util.MessageUtil;
import net.elytrium.limboapi.api.Limbo;
import net.elytrium.limboapi.api.LimboFactory;
import net.elytrium.limboapi.api.chunk.Dimension;
import net.elytrium.limboapi.api.chunk.VirtualWorld;
import net.elytrium.limboapi.api.event.LoginLimboRegisterEvent;

/**
 * Подписывается на {@link LoginLimboRegisterEvent} - событие LimboAPI, которое срабатывает
 * во время процесса логина ДО того, как игрок реально подключится к бэкенд-серверу.
 * <p>
 * Порядок {@link PostOrder#FIRST} гарантирует, что наш обработчик добавит свой
 * onJoinCallback раньше, чем LimboAuth добавит свой - таким образом игрок сначала
 * попадает в captcha-лимбо (если ещё не проходил капчу недавно, см.
 * {@code remember} в config.yml), и только после успешного прохождения captcha
 * мы вызываем {@link LimboFactory#passLoginLimbo(Player)}, что передаёт эстафету
 * следующему зарегистрированному login-лимбо (в типичной связке - лимбо
 * авторизации LimboAuth).
 * <p>
 * Если в вашей версии LimboAPI сигнатура {@code passLoginLimbo} отсутствует или
 * называется иначе - см. README.md.
 */
public class LimboRegisterListener {

    private final LimboCaptchaPlugin plugin;
    private final LimboFactory limboFactory;
    private Limbo captchaLimbo;

    public LimboRegisterListener(LimboCaptchaPlugin plugin, LimboFactory limboFactory) {
        this.plugin = plugin;
        this.limboFactory = limboFactory;
    }

    private Limbo getOrCreateLimbo() {
        if (this.captchaLimbo == null) {
            PluginConfig.WorldSection worldCfg = this.plugin.getPluginConfig().limbo.world;
            Dimension dimension;
            try {
                dimension = Dimension.valueOf(worldCfg.dimension.toUpperCase());
            } catch (IllegalArgumentException ex) {
                dimension = Dimension.OVERWORLD;
            }

            VirtualWorld virtualWorld = this.limboFactory.createVirtualWorld(
                    dimension, worldCfg.x, worldCfg.y, worldCfg.z, worldCfg.yaw, worldCfg.pitch);

            this.captchaLimbo = this.limboFactory.createLimbo(virtualWorld);
        }
        return this.captchaLimbo;
    }

    @Subscribe(order = PostOrder.FIRST)
    public void onLoginLimboRegister(LoginLimboRegisterEvent event) {
        Player player = event.getPlayer();

        event.addOnJoinCallback(() -> {
            PluginConfig config = this.plugin.getPluginConfig();

            // Если игрок уже успешно проходил капчу недавно (config: remember) -
            // не мучаем его повторно, сразу передаём дальше на авторизацию.
            if (config.remember.enabled
                    && this.plugin.getVerificationMemory().isRecentlyVerified(player.getUniqueId(), config.remember.hours)) {
                String remembered = config.message("captcha-remembered");
                if (remembered != null && !remembered.isBlank()) {
                    player.sendMessage(MessageUtil.render(remembered));
                }
                this.limboFactory.passLoginLimbo(player);
                return;
            }

            CaptchaSession session = this.plugin.getSessionManager().create(
                    player,
                    () -> onCaptchaSuccess(player),
                    reasonKey -> onCaptchaFail(player, reasonKey)
            );

            getOrCreateLimbo().spawnPlayer(player, new CaptchaLimboHandler(this.plugin, player, session));
        });
    }

    private void onCaptchaSuccess(Player player) {
        this.plugin.getServer().getScheduler().buildTask(this.plugin, () -> {
            PluginConfig config = this.plugin.getPluginConfig();
            player.sendMessage(MessageUtil.render(config.message("captcha-success")));
            // Отдаём игрока следующему зарегистрированному login-лимбо (LimboAuth)
            this.limboFactory.passLoginLimbo(player);
            this.plugin.getSessionManager().remove(player.getUniqueId());
        }).schedule();
    }

    private void onCaptchaFail(Player player, String reasonKey) {
        this.plugin.getServer().getScheduler().buildTask(this.plugin, () -> {
            PluginConfig config = this.plugin.getPluginConfig();
            String message = config.message(reasonKey);
            if (message == null || message.isBlank()) {
                message = config.message("kick-failed");
            }
            player.disconnect(MessageUtil.render(message));
            this.plugin.getSessionManager().remove(player.getUniqueId());
        }).schedule();
    }
}
