package limbocaptcha.limbo;

import com.velocitypowered.api.proxy.Player;
import com.velocitypowered.api.proxy.ProxyServer;
import com.velocitypowered.api.scheduler.ScheduledTask;
import limbocaptcha.LimboCaptchaPlugin;
import limbocaptcha.config.PluginConfig;
import limbocaptcha.session.CaptchaSession;
import limbocaptcha.util.MessageUtil;
import net.elytrium.limboapi.api.Limbo;
import net.elytrium.limboapi.api.LimboSessionHandler;
import net.elytrium.limboapi.api.player.LimboPlayer;

import java.util.concurrent.TimeUnit;

/**
 * Обработчик сессии игрока внутри captcha-лимбо: показывает ссылку в чате
 * и периодически напоминает о ней, пока капча не будет пройдена.
 */
public class CaptchaLimboHandler implements LimboSessionHandler {

    private final LimboCaptchaPlugin plugin;
    private final Player player;
    private final CaptchaSession session;
    private ScheduledTask reminderTask;

    public CaptchaLimboHandler(LimboCaptchaPlugin plugin, Player player, CaptchaSession session) {
        this.plugin = plugin;
        this.player = player;
        this.session = session;
    }

    @Override
    public void onSpawn(Limbo limbo, LimboPlayer limboPlayer) {
        PluginConfig config = this.plugin.getPluginConfig();
        String link = config.buildCaptchaLink(this.session.getToken());

        this.player.sendMessage(MessageUtil.render(config.message("captcha-prompt"), "%link%", link));

        ProxyServer server = this.plugin.getServer();
        long intervalSeconds = Math.max(5, config.reminderIntervalSeconds);

        this.reminderTask = server.getScheduler()
                .buildTask(this.plugin, () -> {
                    if (this.session.isCompleted() || !this.player.isActive()) {
                        return;
                    }
                    this.player.sendMessage(
                            MessageUtil.render(config.message("captcha-reminder"), "%link%", link));
                })
                .repeat(intervalSeconds, TimeUnit.SECONDS)
                .delay(intervalSeconds, TimeUnit.SECONDS)
                .schedule();
    }

    @Override
    public void onDisconnect() {
        if (this.reminderTask != null) {
            this.reminderTask.cancel();
        }
        if (!this.session.isCompleted()) {
            this.plugin.getSessionManager().remove(this.player.getUniqueId());
        }
    }
}
